A Pen created at CodePen.io. You can find this one at http://codepen.io/edelahoz142/pen/WOYaaN.

 Out of the box, Bootstrap only comes with a traditional horizontal  carousel. This Pen has the HTML and CSS to get it to animate vertically with up/down carousel controls.